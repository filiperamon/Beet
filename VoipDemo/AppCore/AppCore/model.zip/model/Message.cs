﻿using System;

namespace AppCore
{
	public class Message : BaseEntity
	{
		public Contacts Contacs { get; set;}
		public string Msg { get; set;}
		public DateTime Msgdate { get; set;}
		public string Base64img { get; set;}

	}
}

