﻿using System;

namespace AppCore
{
	public class Contacts : BaseEntity
	{
		public User User { get; set;}
		public User Contact { get; set;}
		public DateTime FriendFrom { get; set;}

	}
}

