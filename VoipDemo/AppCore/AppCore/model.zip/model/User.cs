﻿using System;

namespace AppCore
{
	public class User : BaseEntity
	{

		public string Login { get; set; }
		public string Password { get; set; }
		public string Email { get; set; }
		public string Phone { get; set; }


	}
}

