﻿using System;

namespace AppCore
{
	public class BaseEntity	: AbstractEntity
	{
		public override long Cod{ get; set;}

	}
}

