﻿using System;

namespace AppCore
{
	public class Country : BaseEntity
	{
		public int CodeCountry { get; set;}
		public string Name { get; set;}
	}
}

